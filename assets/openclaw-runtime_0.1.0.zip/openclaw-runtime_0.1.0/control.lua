-- OpenClaw Runtime API for Factorio
-- Exposes a curated remote interface:
--   remote.call("openclaw", "state", player_name)
--   remote.call("openclaw", "inventory", player_name)
--   remote.call("openclaw", "nearby_entities", player_name, radius)
--   remote.call("openclaw", "production_stats", player_name)
--   remote.call("openclaw", "chat", message)
--   remote.call("openclaw", "place_entity", player_name, entity_name, dx, dy)
--   remote.call("openclaw", "craft", player_name, item_name, count)
--   remote.call("openclaw", "move_player", player_name, dx, dy)

local MAX_NEARBY_RADIUS = 50
local MAX_PLACE_DISTANCE = 10
local MAX_MOVE_DISTANCE = 25
local MAX_CRAFT_COUNT = 100

local function json(value)
  return helpers.table_to_json(value)
end

local function ok(data)
  data = data or {}
  data.ok = true
  return json(data)
end

local function fail(message, details)
  return json({
    ok = false,
    error = message,
    details = details
  })
end

local function get_player(player_name)
  if not player_name or player_name == "" then
    for _, candidate in pairs(game.connected_players) do
      if candidate and candidate.valid then return candidate, nil end
    end
    for _, candidate in pairs(game.players) do
      if candidate and candidate.valid then return candidate, nil end
    end
    return nil, "no players found"
  end

  local player = game.get_player(player_name)
  if not player then
    return nil, "player not found: " .. tostring(player_name)
  end

  if not player.valid then
    return nil, "player is invalid: " .. tostring(player_name)
  end

  return player, nil
end

local function count_inventory(inv)
  if not inv or not inv.valid then return {} end
  return inv.get_contents()
end

local function safe_position(pos)
  if not pos then return nil end
  return { x = pos.x, y = pos.y }
end

local function surface_safe_name(surface)
  if surface and surface.valid then return surface.name end
  return nil
end

local function entity_summary(entity)
  return {
    name = entity.name,
    type = entity.type,
    position = safe_position(entity.position),
    force = entity.force and entity.force.name or nil,
    health = entity.health,
    unit_number = entity.unit_number
  }
end

local function player_state(player)
  local inv = player.get_main_inventory()

  return {
    name = player.name,
    connected = player.connected,
    position = safe_position(player.position),
    surface = surface_safe_name(player.surface),
    force = player.force and player.force.name or nil,
    character = player.character and player.character.valid and {
      name = player.character.name,
      health = player.character.health
    } or nil,
    inventory = count_inventory(inv),
    crafting_queue_size = player.crafting_queue_size
  }
end

remote.add_interface("openclaw", {
  state = function(player_name)
    local player, err = get_player(player_name)
    if not player then return fail(err) end

    return ok({
      tick = game.tick,
      map = {
        seed = game.default_map_gen_settings and game.default_map_gen_settings.seed or nil,
        difficulty = game.difficulty_settings
      },
      player = player_state(player),
      forces = {
        player = player.force and {
          name = player.force.name,
          current_research = player.force.current_research and player.force.current_research.name or nil,
          research_progress = player.force.research_progress
        } or nil,
        enemy = game.forces.enemy and {
          evolution_factor = game.forces.enemy.evolution_factor
        } or nil
      }
    })
  end,

  inventory = function(player_name)
    local player, err = get_player(player_name)
    if not player then return fail(err) end

    return ok({
      player = player.name,
      inventory = count_inventory(player.get_main_inventory())
    })
  end,

  nearby_entities = function(player_name, radius)
    local player, err = get_player(player_name)
    if not player then return fail(err) end

    radius = tonumber(radius) or 10
    if radius < 1 then radius = 1 end
    if radius > MAX_NEARBY_RADIUS then radius = MAX_NEARBY_RADIUS end

    local pos = player.position
    local entities = player.surface.find_entities_filtered({
      area = {
        { pos.x - radius, pos.y - radius },
        { pos.x + radius, pos.y + radius }
      },
      limit = 200
    })

    local result = {}
    for _, entity in pairs(entities) do
      if entity.valid then
        table.insert(result, entity_summary(entity))
      end
    end

    return ok({
      player = player.name,
      radius = radius,
      count = #result,
      entities = result
    })
  end,

  production_stats = function(player_name)
    local player, err = get_player(player_name)
    if not player then return fail(err) end

    local force = player.force
    return ok({
      force = force.name,
      current_research = force.current_research and force.current_research.name or nil,
      research_progress = force.research_progress,
      item_production_input_counts = force.item_production_statistics.input_counts,
      item_production_output_counts = force.item_production_statistics.output_counts,
      kill_counts = force.kill_count_statistics.output_counts
    })
  end,

  chat = function(message)
    message = tostring(message or "")
    if message == "" then return fail("empty message") end
    if string.len(message) > 500 then
      message = string.sub(message, 1, 500)
    end

    game.print("[OpenClaw] " .. message)
    return ok({ message = message })
  end,

  place_entity = function(player_name, entity_name, dx, dy)
    local player, err = get_player(player_name)
    if not player then return fail(err) end

    entity_name = tostring(entity_name or "")
    if entity_name == "" then return fail("missing entity_name") end
    if not prototypes.entity[entity_name] then
      return fail("unknown entity prototype", entity_name)
    end

    dx = tonumber(dx) or 0
    dy = tonumber(dy) or 0
    if math.abs(dx) > MAX_PLACE_DISTANCE or math.abs(dy) > MAX_PLACE_DISTANCE then
      return fail("placement offset too large", { max = MAX_PLACE_DISTANCE, dx = dx, dy = dy })
    end

    local pos = {
      x = player.position.x + dx,
      y = player.position.y + dy
    }

    local entity = player.surface.create_entity({
      name = entity_name,
      position = pos,
      force = player.force,
      raise_built = true
    })

    if not entity then return fail("create_entity returned nil") end

    return ok({
      placed = entity_summary(entity)
    })
  end,

  craft = function(player_name, item_name, count)
    local player, err = get_player(player_name)
    if not player then return fail(err) end

    item_name = tostring(item_name or "")
    count = math.floor(tonumber(count) or 1)

    if item_name == "" then return fail("missing item_name") end
    if count < 1 then count = 1 end
    if count > MAX_CRAFT_COUNT then count = MAX_CRAFT_COUNT end
    if not prototypes.item[item_name] then
      return fail("unknown item prototype", item_name)
    end

    local queued = player.begin_crafting({
      count = count,
      recipe = item_name
    })

    return ok({
      item = item_name,
      requested = count,
      queued = queued
    })
  end,

  move_player = function(player_name, dx, dy)
    local player, err = get_player(player_name)
    if not player then return fail(err) end

    dx = tonumber(dx) or 0
    dy = tonumber(dy) or 0

    if math.abs(dx) > MAX_MOVE_DISTANCE or math.abs(dy) > MAX_MOVE_DISTANCE then
      return fail("move offset too large", { max = MAX_MOVE_DISTANCE, dx = dx, dy = dy })
    end

    local target = {
      x = player.position.x + dx,
      y = player.position.y + dy
    }

    local ok_teleport = player.teleport(target, player.surface)
    if not ok_teleport then return fail("teleport failed", target) end

    return ok({
      player = player.name,
      position = safe_position(player.position)
    })
  end
})

commands.add_command("openclaw-version", "Print the OpenClaw Runtime API mod version.", function(command)
  if command.player_index then
    local player = game.get_player(command.player_index)
    if player then player.print("openclaw-runtime 0.1.0") end
  else
    log("openclaw-runtime 0.1.0")
  end
end)

commands.add_command("openclaw-inventory", "Print your OpenClaw Runtime inventory JSON.", function(command)
  if not command.player_index then
    log(fail("openclaw-inventory must be run by a player"))
    return
  end

  local player = game.get_player(command.player_index)
  if not player then
    log(fail("player not found for command index", command.player_index))
    return
  end

  local result = ok({
    player = player.name,
    inventory = count_inventory(player.get_main_inventory())
  })
  player.print(result)
  log("[OpenClaw inventory] " .. result)
end)
