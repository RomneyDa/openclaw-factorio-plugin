-- OpenClaw Runtime API for Factorio
-- Curated remote interface for safe-ish AI inspection and bounded actions.

local VERSION = "0.2.0"
local MAX_NEARBY_RADIUS = 75
local MAX_ENTITY_LIMIT = 300
local MAX_PLACE_DISTANCE = 10
local MAX_MOVE_DISTANCE = 25
local MAX_CRAFT_COUNT = 100
local MAX_ITEM_COUNT = 1000
local MAX_SEARCH_LIMIT = 100

local function json(value)
  return helpers.table_to_json(value)
end

local function ok(data)
  data = data or {}
  data.ok = true
  data.version = VERSION
  return json(data)
end

local function fail(message, details)
  return json({ ok = false, version = VERSION, error = message, details = details })
end

local function clamp_number(value, default_value, min_value, max_value)
  value = tonumber(value) or default_value
  if value < min_value then value = min_value end
  if value > max_value then value = max_value end
  return value
end

local function safe_position(pos)
  if not pos then return nil end
  return { x = pos.x, y = pos.y }
end

local function surface_safe_name(surface)
  if surface and surface.valid then return surface.name end
  return nil
end

local function count_inventory(inv)
  if not inv or not inv.valid then return {} end
  return inv.get_contents()
end

local function get_player(player_name)
  if not player_name or player_name == "" then
    for _, candidate in pairs(game.connected_players) do
      if candidate and candidate.valid then return candidate, nil end
    end
    for _, candidate in pairs(game.players) do
      if candidate and candidate.valid then return candidate, nil end
    end
    return nil, "no players found"
  end

  local player = game.get_player(player_name)
  if not player then return nil, "player not found: " .. tostring(player_name) end
  if not player.valid then return nil, "player is invalid: " .. tostring(player_name) end
  return player, nil
end

local function entity_summary(entity)
  if not entity or not entity.valid then return nil end
  return {
    name = entity.name,
    type = entity.type,
    position = safe_position(entity.position),
    force = entity.force and entity.force.name or nil,
    health = entity.health,
    max_health = entity.prototype and entity.prototype.max_health or nil,
    unit_number = entity.unit_number,
    direction = entity.direction,
    active = entity.active,
    operable = entity.operable,
    destructible = entity.destructible,
    minable = entity.prototype and entity.prototype.mineable_properties and entity.prototype.mineable_properties.minable or nil
  }
end

local function selected_summary(player)
  if player and player.selected and player.selected.valid then
    return entity_summary(player.selected)
  end
  return nil
end

local function player_state(player)
  return {
    name = player.name,
    index = player.index,
    connected = player.connected,
    position = safe_position(player.position),
    surface = surface_safe_name(player.surface),
    force = player.force and player.force.name or nil,
    color = player.color,
    controller_type = player.controller_type,
    character = player.character and player.character.valid and {
      name = player.character.name,
      health = player.character.health,
      max_health = player.character.prototype and player.character.prototype.max_health or nil
    } or nil,
    selected = selected_summary(player),
    inventory = count_inventory(player.get_main_inventory()),
    crafting_queue_size = player.crafting_queue_size,
    walking_state = player.walking_state
  }
end

local function force_summary(force)
  if not force or not force.valid then return nil end
  return {
    name = force.name,
    current_research = force.current_research and force.current_research.name or nil,
    research_progress = force.research_progress,
    worker_robots_speed_modifier = force.worker_robots_speed_modifier,
    manual_mining_speed_modifier = force.manual_mining_speed_modifier,
    manual_crafting_speed_modifier = force.manual_crafting_speed_modifier,
    character_running_speed_modifier = force.character_running_speed_modifier,
    character_inventory_slots_bonus = force.character_inventory_slots_bonus,
    evolution_factor = force.evolution_factor
  }
end

local function technology_summary(tech)
  return {
    name = tech.name,
    enabled = tech.enabled,
    researched = tech.researched,
    level = tech.level,
    research_unit_count = tech.research_unit_count,
    research_unit_energy = tech.research_unit_energy,
    upgrade = tech.upgrade,
    visible_when_disabled = tech.visible_when_disabled,
    prerequisites = tech.prerequisites
  }
end

local function recipe_summary(recipe)
  return {
    name = recipe.name,
    enabled = recipe.enabled,
    category = recipe.category,
    energy = recipe.energy,
    hidden = recipe.hidden,
    ingredients = recipe.ingredients,
    products = recipe.products
  }
end

local function prototype_name_list(tbl, query, limit)
  query = tostring(query or "")
  limit = clamp_number(limit, 25, 1, MAX_SEARCH_LIMIT)
  local result = {}
  for name, proto in pairs(tbl) do
    if query == "" or string.find(name, query, 1, true) then
      table.insert(result, name)
      if #result >= limit then break end
    end
  end
  table.sort(result)
  return result
end

local function find_nearby(player, radius, name, entity_type, force_name, limit)
  radius = clamp_number(radius, 10, 1, MAX_NEARBY_RADIUS)
  limit = clamp_number(limit, 200, 1, MAX_ENTITY_LIMIT)
  local pos = player.position
  local filter = {
    area = {{ pos.x - radius, pos.y - radius }, { pos.x + radius, pos.y + radius }},
    limit = limit
  }
  if name and tostring(name) ~= "" then filter.name = tostring(name) end
  if entity_type and tostring(entity_type) ~= "" then filter.type = tostring(entity_type) end
  if force_name and tostring(force_name) ~= "" then filter.force = tostring(force_name) end
  local entities = player.surface.find_entities_filtered(filter)
  local result = {}
  for _, entity in pairs(entities) do
    if entity.valid then table.insert(result, entity_summary(entity)) end
  end
  return radius, result
end

local function get_main_inventory_or_fail(player)
  local inv = player.get_main_inventory()
  if not inv or not inv.valid then return nil, "player has no valid main inventory" end
  return inv, nil
end

remote.add_interface("openclaw", {
  capabilities = function()
    return ok({
      read = {"capabilities", "players", "state", "inventory", "selected_entity", "nearby_entities", "resources", "production_stats", "force_state", "research", "technologies", "recipes", "prototypes_search", "surface_info"},
      safe_write = {"chat"},
      mutating = {"craft", "give_item", "remove_item", "place_entity", "destroy_selected", "mine_selected", "move_player"},
      limits = { nearby_radius = MAX_NEARBY_RADIUS, entity_limit = MAX_ENTITY_LIMIT, place_distance = MAX_PLACE_DISTANCE, move_distance = MAX_MOVE_DISTANCE, craft_count = MAX_CRAFT_COUNT, item_count = MAX_ITEM_COUNT }
    })
  end,

  players = function()
    local result = {}
    for _, player in pairs(game.players) do
      if player.valid then table.insert(result, { name = player.name, index = player.index, connected = player.connected, force = player.force and player.force.name or nil, surface = surface_safe_name(player.surface), position = safe_position(player.position) }) end
    end
    return ok({ count = #result, players = result })
  end,

  state = function(player_name)
    local player, err = get_player(player_name)
    if not player then return fail(err) end
    return ok({
      tick = game.tick,
      map = { seed = game.default_map_gen_settings and game.default_map_gen_settings.seed or nil, difficulty = game.difficulty_settings },
      player = player_state(player),
      forces = { player = force_summary(player.force), enemy = game.forces.enemy and force_summary(game.forces.enemy) or nil }
    })
  end,

  inventory = function(player_name)
    local player, err = get_player(player_name)
    if not player then return fail(err) end
    return ok({ player = player.name, inventory = count_inventory(player.get_main_inventory()) })
  end,

  selected_entity = function(player_name)
    local player, err = get_player(player_name)
    if not player then return fail(err) end
    return ok({ player = player.name, selected = selected_summary(player) })
  end,

  nearby_entities = function(player_name, radius, name, entity_type, force_name, limit)
    local player, err = get_player(player_name)
    if not player then return fail(err) end
    local used_radius, entities = find_nearby(player, radius, name, entity_type, force_name, limit)
    return ok({ player = player.name, radius = used_radius, count = #entities, entities = entities })
  end,

  resources = function(player_name, radius, limit)
    local player, err = get_player(player_name)
    if not player then return fail(err) end
    local used_radius, entities = find_nearby(player, radius, nil, "resource", nil, limit)
    return ok({ player = player.name, radius = used_radius, count = #entities, resources = entities })
  end,

  production_stats = function(player_name)
    local player, err = get_player(player_name)
    if not player then return fail(err) end
    local force = player.force
    return ok({
      force = force.name,
      current_research = force.current_research and force.current_research.name or nil,
      research_progress = force.research_progress,
      item_production_input_counts = force.item_production_statistics.input_counts,
      item_production_output_counts = force.item_production_statistics.output_counts,
      fluid_production_input_counts = force.fluid_production_statistics.input_counts,
      fluid_production_output_counts = force.fluid_production_statistics.output_counts,
      kill_counts = force.kill_count_statistics.output_counts
    })
  end,

  force_state = function(player_name)
    local player, err = get_player(player_name)
    if not player then return fail(err) end
    return ok({ force = force_summary(player.force) })
  end,

  research = function(player_name)
    local player, err = get_player(player_name)
    if not player then return fail(err) end
    local force = player.force
    return ok({ force = force.name, current_research = force.current_research and technology_summary(force.current_research) or nil, research_progress = force.research_progress, technologies_researched_count = force.technologies_researched })
  end,

  technologies = function(player_name, query, limit)
    local player, err = get_player(player_name)
    if not player then return fail(err) end
    query = tostring(query or "")
    limit = clamp_number(limit, 25, 1, MAX_SEARCH_LIMIT)
    local result = {}
    for name, tech in pairs(player.force.technologies) do
      if query == "" or string.find(name, query, 1, true) then
        table.insert(result, technology_summary(tech))
        if #result >= limit then break end
      end
    end
    return ok({ force = player.force.name, query = query, count = #result, technologies = result })
  end,

  recipes = function(player_name, query, limit)
    local player, err = get_player(player_name)
    if not player then return fail(err) end
    query = tostring(query or "")
    limit = clamp_number(limit, 25, 1, MAX_SEARCH_LIMIT)
    local result = {}
    for name, recipe in pairs(player.force.recipes) do
      if query == "" or string.find(name, query, 1, true) then
        table.insert(result, recipe_summary(recipe))
        if #result >= limit then break end
      end
    end
    return ok({ force = player.force.name, query = query, count = #result, recipes = result })
  end,

  prototypes_search = function(kind, query, limit)
    kind = tostring(kind or "item")
    local source = prototypes.item
    if kind == "entity" then source = prototypes.entity end
    if kind == "fluid" then source = prototypes.fluid end
    if kind == "recipe" then source = prototypes.recipe end
    if kind == "technology" then source = prototypes.technology end
    if not source then return fail("unsupported prototype kind", kind) end
    return ok({ kind = kind, query = tostring(query or ""), names = prototype_name_list(source, query, limit) })
  end,

  surface_info = function(player_name)
    local player, err = get_player(player_name)
    if not player then return fail(err) end
    local surface = player.surface
    return ok({ name = surface.name, index = surface.index, daytime = surface.daytime, ticks_per_day = surface.ticks_per_day, solar_power_multiplier = surface.solar_power_multiplier, pollution_at_player = surface.get_pollution(player.position), freeze_daytime = surface.freeze_daytime })
  end,

  chat = function(message)
    message = tostring(message or "")
    if message == "" then return fail("empty message") end
    if string.len(message) > 500 then message = string.sub(message, 1, 500) end
    game.print("[OpenClaw] " .. message)
    return ok({ message = message })
  end,

  craft = function(player_name, item_name, count)
    local player, err = get_player(player_name)
    if not player then return fail(err) end
    item_name = tostring(item_name or "")
    count = math.floor(clamp_number(count, 1, 1, MAX_CRAFT_COUNT))
    if item_name == "" then return fail("missing item_name") end
    if not prototypes.item[item_name] then return fail("unknown item prototype", item_name) end
    local queued = player.begin_crafting({ count = count, recipe = item_name })
    return ok({ item = item_name, requested = count, queued = queued, crafting_queue_size = player.crafting_queue_size })
  end,

  give_item = function(player_name, item_name, count)
    local player, err = get_player(player_name)
    if not player then return fail(err) end
    local inv, inv_err = get_main_inventory_or_fail(player)
    if not inv then return fail(inv_err) end
    item_name = tostring(item_name or "")
    count = math.floor(clamp_number(count, 1, 1, MAX_ITEM_COUNT))
    if not prototypes.item[item_name] then return fail("unknown item prototype", item_name) end
    local inserted = inv.insert({ name = item_name, count = count })
    return ok({ item = item_name, requested = count, inserted = inserted, inventory = count_inventory(inv) })
  end,

  remove_item = function(player_name, item_name, count)
    local player, err = get_player(player_name)
    if not player then return fail(err) end
    local inv, inv_err = get_main_inventory_or_fail(player)
    if not inv then return fail(inv_err) end
    item_name = tostring(item_name or "")
    count = math.floor(clamp_number(count, 1, 1, MAX_ITEM_COUNT))
    if not prototypes.item[item_name] then return fail("unknown item prototype", item_name) end
    local removed = inv.remove({ name = item_name, count = count })
    return ok({ item = item_name, requested = count, removed = removed, inventory = count_inventory(inv) })
  end,

  place_entity = function(player_name, entity_name, dx, dy)
    local player, err = get_player(player_name)
    if not player then return fail(err) end
    entity_name = tostring(entity_name or "")
    if entity_name == "" then return fail("missing entity_name") end
    if not prototypes.entity[entity_name] then return fail("unknown entity prototype", entity_name) end
    dx = tonumber(dx) or 0
    dy = tonumber(dy) or 0
    if math.abs(dx) > MAX_PLACE_DISTANCE or math.abs(dy) > MAX_PLACE_DISTANCE then return fail("placement offset too large", { max = MAX_PLACE_DISTANCE, dx = dx, dy = dy }) end
    local pos = { x = player.position.x + dx, y = player.position.y + dy }
    local entity = player.surface.create_entity({ name = entity_name, position = pos, force = player.force, raise_built = true })
    if not entity then return fail("create_entity returned nil") end
    return ok({ placed = entity_summary(entity) })
  end,

  destroy_selected = function(player_name)
    local player, err = get_player(player_name)
    if not player then return fail(err) end
    local entity = player.selected
    if not entity or not entity.valid then return fail("no selected entity") end
    local summary = entity_summary(entity)
    local destroyed = entity.destroy({ raise_destroy = true })
    return ok({ destroyed = destroyed, entity = summary })
  end,

  mine_selected = function(player_name)
    local player, err = get_player(player_name)
    if not player then return fail(err) end
    local entity = player.selected
    if not entity or not entity.valid then return fail("no selected entity") end
    local summary = entity_summary(entity)
    local mined = player.mine_entity(entity, true)
    return ok({ mined = mined, entity = summary, inventory = count_inventory(player.get_main_inventory()) })
  end,

  move_player = function(player_name, dx, dy)
    local player, err = get_player(player_name)
    if not player then return fail(err) end
    dx = tonumber(dx) or 0
    dy = tonumber(dy) or 0
    if math.abs(dx) > MAX_MOVE_DISTANCE or math.abs(dy) > MAX_MOVE_DISTANCE then return fail("move offset too large", { max = MAX_MOVE_DISTANCE, dx = dx, dy = dy }) end
    local target = { x = player.position.x + dx, y = player.position.y + dy }
    local ok_teleport = player.teleport(target, player.surface)
    if not ok_teleport then return fail("teleport failed", target) end
    return ok({ player = player.name, position = safe_position(player.position) })
  end
})

commands.add_command("openclaw-version", "Print the OpenClaw Runtime API mod version.", function(command)
  local message = "openclaw-runtime " .. VERSION
  if command.player_index then
    local player = game.get_player(command.player_index)
    if player then player.print(message) end
  else
    log(message)
  end
end)

commands.add_command("openclaw-inventory", "Print your OpenClaw Runtime inventory JSON.", function(command)
  if not command.player_index then log(fail("openclaw-inventory must be run by a player")); return end
  local player = game.get_player(command.player_index)
  if not player then log(fail("player not found for command index", command.player_index)); return end
  local result = ok({ player = player.name, inventory = count_inventory(player.get_main_inventory()) })
  player.print(result)
  log("[OpenClaw inventory] " .. result)
end)
