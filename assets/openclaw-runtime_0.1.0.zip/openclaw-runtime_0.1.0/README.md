# OpenClaw Runtime API for Factorio

This mod exposes a curated `remote` interface named `openclaw`.

Example RCON call:

```bash
/c rcon.print(remote.call("openclaw", "state", "YOUR_PLAYER_NAME"))
```

Install by placing `openclaw-runtime_0.1.0.zip` in your Factorio mods folder and enabling it.
